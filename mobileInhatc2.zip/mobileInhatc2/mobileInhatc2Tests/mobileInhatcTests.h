//
//  mobileGm2Tests.h
//  mobileGm2Tests
//
//  Created by shim on 12. 10. 22..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface mobileGm2Tests : SenTestCase

@end
