//
//  AESExtention.h
//  mobileGm
//
//  Created by shim on 13. 3. 13..
//  Copyright (c) 2013년 hanshinit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCryptor.h>


@interface AESExtention : NSObject {
    NSString *aesKey;
}

@property (nonatomic, retain) NSString *aesKey;

-(NSString*) aesEncryptString:(NSString*)textString;
-(NSString*) aesDecryptString:(NSString*)textString;
-(NSData *)AES128EncryptWithKey:(NSString *)key theData:(NSData *)Data;
-(NSData *)AES128DecryptWithKey:(NSString *)key theData:(NSData *)Data;
-(NSString *)hexEncode:(NSData *)data;
-(NSData*) decodeHexString : (NSString *)hexString;

@end
