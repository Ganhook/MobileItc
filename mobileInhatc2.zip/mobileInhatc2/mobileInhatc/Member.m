//
//  Member.m
//  mobileGm
//
//  Created by shim on 12. 11. 10..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import "Member.h"

@implementation Member

@synthesize memberKey;
@synthesize memberId;
@synthesize memberName;
@synthesize memberType;
@synthesize memberMobile;
@synthesize memberPost;
@synthesize memberAddr1;
@synthesize memberAddr2;
@synthesize memberDupinfo;
@synthesize memberEmail;

@end
