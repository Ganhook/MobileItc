//
//  MenuHomeViewController.h
//  mobileGm
//
//  Created by shim on 12. 10. 31..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuHomeViewController : UIViewController <UIWebViewDelegate> {
    NSURL *myURL;
    IBOutlet UIWebView *webView;
    UIActivityIndicatorView *loadAct;
}

@property (nonatomic, retain) NSURL *myURL;
@property (nonatomic, retain) IBOutlet UIWebView *webView;
@property (nonatomic, retain) UIActivityIndicatorView *loadAct;

@end