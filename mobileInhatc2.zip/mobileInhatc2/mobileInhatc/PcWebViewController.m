//
//  PcWebViewController.m
//  mobileGm
//
//  Created by shim on 12. 10. 29..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import "PcWebViewController.h"

@interface PcWebViewController ()

@end

@implementation PcWebViewController

@synthesize webView;
@synthesize loadAct;
@synthesize result_msg;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.title = @"인하공업전문대학홈페이지";
    
    // 네비게이션바 배경 이미지 변경
    //[self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"sub_title_bg.png"] forBarMetrics:UIBarMetricsDefault];
        
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated
{
    self.webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.webView.scalesPageToFit = YES;
    self.webView.dataDetectorTypes = UIDataDetectorTypeAll;
    self.webView.delegate = self;
    
    NSURL *myURL = [NSURL URLWithString:@"http://cms.itc.ac.kr/site/inhatc/main.do"];
    
    NSURLRequest *myURLReq = [NSURLRequest requestWithURL:myURL];
    [self.webView loadRequest:myURLReq];
    
    self.loadAct = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        self.loadAct.frame = CGRectMake(344, 450, 37, 37);
    } else {
        self.loadAct.frame = CGRectMake(142, 188, 37, 37);
    }
    [self.view addSubview:self.loadAct];

}

- (void)viewDidUnload
{
    [self setWebView:nil];
    [self setLoadAct:nil];
    [self setResult_msg:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    if(self.webView.loading) [self.webView stopLoading];
	self.webView.delegate = nil;
    [self.webView release];
    [self.loadAct release];
    [self.result_msg release];
    [super dealloc];
}

#pragma mark -
#pragma mark UIWebViewDelegate Methods

- (BOOL)webView:(UIWebView*)webView	shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType {
	
    
	if (UIWebViewNavigationTypeLinkClicked == navigationType) {
		NSURL *urlAdd = request.URL;
        NSString *urlStr  = [urlAdd absoluteString];        
        //NSLog(@"URL = %@", urlStr);
		
        if(	[self contain:@".pdf" in:urlStr] || [self contain:@".zip" in:urlStr] || [self contain:@".hwp" in:urlStr] || [self contain:@".xls" in:urlStr] || [self contain:@".mp4" in:urlStr]) {
            
			[[UIApplication sharedApplication] openURL:[request URL]];
			return NO;
		}
        //else if([self contain:@"tel" in:urlStr]) {
        //    [[UIApplication sharedApplication] openURL:[request URL]];
        //    return NO;
        //}
        
		return YES;
	}
	else if(UIWebViewNavigationTypeFormSubmitted == navigationType) {
        NSURL *urlAdd = request.URL;
        NSString *urlStr  = [urlAdd absoluteString];
	}
    
	return YES;
}

- (BOOL)contain:(NSString*)string in:(NSString*)target {
	if ([string length] > [target length]) {
		return NO;
	}
	
	for (int i = 0; i <[target length] - [string length] + 1; i++) {
		if (![string compare:[target substringWithRange:NSMakeRange(i, [string length])]]) {
			return YES;
		}
	}
	
	return NO;
}


- (void) callWithOpenURL:(NSString *)phoneNumber {
    NSURL *url = [NSURL URLWithString:[@"tel://" stringByAppendingString:phoneNumber]];
    [[UIApplication sharedApplication] openURL:url];
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
}

//웹 뷰가 로딩을 시작했을 때 호출되는 메서드
- (void)webViewDidStartLoad:(UIWebView *)wv {
	//NSLog(@"webViewDidStartLoad:");
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    [self.loadAct startAnimating];
}

//웹 뷰의 로딩이 종료되었을 때
- (void)webViewDidFinishLoad:(UIWebView *)wv {
	//NSLog(@"webViewDidFinishLoad:");
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    result_msg.text = @"";
    [self.loadAct stopAnimating];
}

//웹 뷰의 로딩이 실패했을 때 호출되는 메서드
- (void)webView:(UIWebView *)wv didFailLoadWithError:(NSError *)error {
    /*
     NSLog(@"webView:didFailLoadWithError:");
     [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
     
     NSString *errorString = [error localizedDescription];
     NSString *errorTitle = [NSString stringWithFormat:@"Error (%d)", error.code];
     
     UIAlertView *errorView = [[UIAlertView alloc] initWithTitle:errorTitle message:errorString delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
     [errorView show];
     [errorView autorelease];
     */
    result_msg.text = @"페이지를 로딩할 수 없습니다.";
	[self.loadAct stopAnimating];
}

@end
