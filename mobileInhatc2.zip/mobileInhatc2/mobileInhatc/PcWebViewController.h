//
//  PcWebViewController.h
//  mobileGm
//
//  Created by shim on 12. 10. 29..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PcWebViewController : UIViewController <UIWebViewDelegate> {
    IBOutlet UIWebView *webView;
    UILabel *result_msg;
    UIActivityIndicatorView * loadAct;
}

@property (nonatomic, retain) IBOutlet UIWebView *webView;
@property (nonatomic, retain) IBOutlet UILabel *result_msg;
@property (nonatomic, retain) UIActivityIndicatorView * loadAct;

@end
