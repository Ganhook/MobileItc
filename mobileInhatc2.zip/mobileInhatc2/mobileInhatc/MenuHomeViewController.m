//
//  MenuHomeViewController.m
//  mobileGm
//
//  Created by shim on 12. 10. 31..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import "MenuHomeViewController.h"

@interface MenuHomeViewController ()

@end

@implementation MenuHomeViewController

@synthesize myURL;
@synthesize webView;
@synthesize loadAct;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 네이게이션바를 안보이게 함.
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    
    // 아이폰 화면 크기별
    if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)]){
        
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        if (screenBounds.size.height == 568)
        {
            // code for 4-inch screen
            if([self.webView isKindOfClass:[UITabBar class]])
            {
                [self.webView setFrame:CGRectMake(self.webView.frame.origin.x, 530, self.webView.frame.size.width, self.webView.frame.size.height)];
                //NSLog(@"1111111111111==>> %f", self.webView.frame.size.height);
            }
            else
            {
                [self.webView setFrame:CGRectMake(0, 20, self.webView.frame.size.width, 550)];
                //NSLog(@"22222222222222==>> %f", self.webView.frame.size.height);
            }
        }
        else
        {
            // code for 3.5-inch screen
            if([self.webView isKindOfClass:[UITabBar class]])
            {
                [self.webView setFrame:CGRectMake(self.webView.frame.origin.x, 450, self.webView.frame.size.width, self.webView.frame.size.height)];
                //NSLog(@"3333333333333==>> %f", self.webView.frame.size.height);
            }
            else
            {
                [self.webView setFrame:CGRectMake(0, 0, self.webView.frame.size.width, 480)];
                //NSLog(@"4444444444444==>> %f", self.webView.frame.size.height);
            }
        }
        
    }
    
    // userAgetn값 변경
    NSString *deviceModel = [[UIDevice currentDevice].model stringByReplacingOccurrencesOfString:@"" withString:@""];
    NSString *userAgent = [NSString stringWithFormat:@"Mozilla/5.0 (%@; CPU OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Mobile/9A334, itcApp_i_phone",deviceModel];
    NSDictionary *dictionnary = [[NSDictionary alloc] initWithObjectsAndKeys:userAgent,@"UserAgent", nil];
    [[NSUserDefaults standardUserDefaults] registerDefaults:dictionnary];
    //[dictionnary release];
    
    self.webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.webView.scalesPageToFit = YES;
    self.webView.dataDetectorTypes = UIDataDetectorTypeAll;
    self.webView.delegate = self;
    
    self.myURL = [NSURL URLWithString:@"http://cms.itc.ac.kr/site/mobile/main.do"];
    
    NSURLRequest *myURLReq = [NSURLRequest requestWithURL:self.myURL];
    
    [self.webView loadRequest:myURLReq];
    
    self.loadAct = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        self.loadAct.frame = CGRectMake(344, 450, 37, 37);
    } else {
        self.loadAct.frame = CGRectMake(142, 188, 37, 37);
    }
    [self.view addSubview:self.loadAct];
    
    // Do any additional setup after loading the view, typically from a nib.
    
}


- (void)viewWillAppear:(BOOL)animated
{
    // userAgetn값 변경
    NSString *deviceModel = [[UIDevice currentDevice].model stringByReplacingOccurrencesOfString:@"" withString:@""];
    NSString *userAgent = [NSString stringWithFormat:@"Mozilla/5.0 (%@; CPU OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Mobile/9A334, itcApp_i_phone",deviceModel];
    NSDictionary *dictionnary = [[NSDictionary alloc] initWithObjectsAndKeys:userAgent,@"UserAgent", nil];
    [[NSUserDefaults standardUserDefaults] registerDefaults:dictionnary];
    //[dictionnary release];
    
    self.webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.webView.scalesPageToFit = YES;
    self.webView.dataDetectorTypes = UIDataDetectorTypeAll;
    self.webView.delegate = self;
    
    self.myURL = [NSURL URLWithString:@"http://cms.itc.ac.kr/site/mobile/main.do"];
    
    NSURLRequest *myURLReq = [NSURLRequest requestWithURL:self.myURL];
    
    [self.webView loadRequest:myURLReq];
    
    self.loadAct = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        self.loadAct.frame = CGRectMake(344, 450, 37, 37);
    } else {
        self.loadAct.frame = CGRectMake(142, 188, 37, 37);
    }
    [self.view addSubview:self.loadAct];
}

#pragma mark -
#pragma mark UIWebViewDelegate Methods

- (BOOL)webView:(UIWebView*)webView	shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType {
    
    if (UIWebViewNavigationTypeLinkClicked == navigationType) {
		NSURL *urlAdd = request.URL;
        NSString *urlStr  = [urlAdd absoluteString];
        //NSLog(@"URL = %@", urlStr);
        
        if(	[urlStr rangeOfString:@".pdf"].location != NSNotFound || [urlStr rangeOfString:@".zip"].location != NSNotFound || [urlStr rangeOfString:@".hwp"].location != NSNotFound || [urlStr rangeOfString:@".xls"].location != NSNotFound || [urlStr rangeOfString:@".mp4"].location != NSNotFound || [urlStr rangeOfString:@".jpg"].location != NSNotFound) {
            
            //NSLog(@"URL11 = %@", urlStr);
            
			[[UIApplication sharedApplication] openURL:[request URL]];
			return NO;
		} else if([urlStr rangeOfString:@"http://cms.itc.ac.kr"].location == NSNotFound || [urlStr rangeOfString:@"http://cms.itc.ac.kr/site/inhatc/"].location != NSNotFound || [urlStr rangeOfString:@"iphoneApp"].location != NSNotFound)
        {
            
            //NSLog(@"URL22 = %@", urlStr);
            
            NSURL *url = [[NSURL alloc] initWithString:urlStr];
            [[UIApplication sharedApplication] openURL:url];
            
            // 현재 URL 유지
            NSString *strUrl = self.webView.request.URL.absoluteString;
            //NSLog(@"2===>>> %@", strUrl);
            
            NSURL *theURL = [NSURL URLWithString:strUrl];
            [self.webView loadRequest:[NSURLRequest requestWithURL:theURL]];
            
            /*
             // 웹뷰2페이지로 이동
             WebViewController *webViewController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
             
             webViewController.menuTitle = @"";
             webViewController.meunUrl = urlStr;
             webViewController.menuTopTitle = @"";
             
             [self.navigationController pushViewController:webViewController animated:YES];
             [webViewController release];
             */

        }
        //else if([self contain:@"tel" in:urlStr]) {
        //    [[UIApplication sharedApplication] openURL:[request URL]];
        //    return NO;
        //}
        
		return YES;
	}
	else if(UIWebViewNavigationTypeFormSubmitted == navigationType) {
        NSURL *urlAdd = request.URL;
        NSString *urlStr  = [urlAdd absoluteString];
	}
    
	return YES;
}



- (void)didReceiveMemoryWarning
{
    NSLog(@"MenuHomeViewController 메모리 부족!!!!");
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    if(self.webView.loading) {
        [self.webView stopLoading];
        self.webView.delegate = nil;
    }
    [self.webView release];
    [self.loadAct release];
    [super dealloc];
}

@end
