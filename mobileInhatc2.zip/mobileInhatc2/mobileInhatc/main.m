//
//  main.m
//  mobileInhatc
//
//  Created by shim on 12. 10. 22..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "mobileInhatcAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([mobileInhatcAppDelegate class]));
    }
}
