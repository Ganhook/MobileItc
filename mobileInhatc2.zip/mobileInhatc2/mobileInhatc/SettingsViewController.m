//
//  SettingsViewController.m
//  mobileGm
//
//  Created by shim on 12. 10. 29..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import "SettingsViewController.h"
#import "PcWebViewController.h"
#import "VersionViewController.h"
#import "TouchXML.h"                    // 테이블 로딩시 touchXML로 이용

@interface SettingsViewController ()

@end

@implementation SettingsViewController

@synthesize myData;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"설정";
    
    // 네비게이션바 배경 이미지 변경
    //[self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"sub_title_bg.png"] forBarMetrics:UIBarMetricsDefault];
    
    // 다음 화면으로 넘어갔을 때 돌아오는 Back버튼을 커스터마이징
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:@"이전" style:UIBarButtonItemStyleBordered target:nil action:nil];
    [backButton setTintColor:[UIColor blueColor]];
    [[self navigationItem] setBackBarButtonItem:backButton];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)viewWillAppear:(BOOL)animated
{
    myData = [[NSArray alloc] initWithObjects:@"PC버전",@"버전정보", nil];
    [self.tableView reloadData];
}

- (void)viewDidUnload
{
    [self setMyData:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [self.myData release];
    [super dealloc];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [myData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    cell.textLabel.text = [myData objectAtIndex:indexPath.row];
    cell.accessoryType = UITableViewCellStyleValue2;

    // Configure the cell...
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSLog([myData objectAtIndex:indexPath.row]);
    
    // Navigation logic may go here. Create and push another view controller.
    
    if ([[myData objectAtIndex:indexPath.row] isEqualToString:@"PC버전"]) {
        PcWebViewController *pcWebViewController = [[PcWebViewController alloc] initWithNibName:@"PcWebViewController" bundle:nil];
        
        [self.navigationController pushViewController:pcWebViewController animated:YES];
        [pcWebViewController release];
    } else if ([[myData objectAtIndex:indexPath.row] isEqualToString:@"버전정보"]) {
        VersionViewController *versionViewController = [[VersionViewController alloc] initWithNibName:@"VersionViewController" bundle:nil];
        
        [self.navigationController pushViewController:versionViewController animated:YES];
        [versionViewController release];
    }


}

@end
