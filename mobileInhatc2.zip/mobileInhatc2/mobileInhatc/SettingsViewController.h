//
//  SettingsViewController.h
//  mobileGm
//
//  Created by shim on 12. 10. 29..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UITableViewController {
    NSArray *myData;
}

@property (nonatomic, retain) NSArray *myData;

@end
