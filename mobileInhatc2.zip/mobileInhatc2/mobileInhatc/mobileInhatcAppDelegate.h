//
//  mobileInhatcAppDelegate.h
//  mobileInhatc
//
//  Created by shim on 12. 10. 22..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mobileInhatcAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
