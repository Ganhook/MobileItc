//
//  VersionViewController.m
//  mobileGm
//
//  Created by shim on 12. 10. 29..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import "VersionViewController.h"

@interface VersionViewController ()

@end

@implementation VersionViewController

@synthesize labVersion;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"버전정보";
    
    // 네비게이션바 배경 이미지 변경
    //[self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"sub_title_bg.png"] forBarMetrics:UIBarMetricsDefault];
    
    // 아이폰 화면 크기별 아이콘 위치 정하기
    if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)]){
        CGFloat scale = [[UIScreen mainScreen] scale];
        
        if (scale == 2.f) {
            //NSLog(@"Retina!");	// iPhone 4 (640*960)
            labVersion.frame = CGRectMake(120, 192, 110, 20);

        } else {
            //NSLog(@"Non-retina!");	// iPhone3GS iOS 4.x 또는 iPad 3.2 (320*480)
            labVersion.frame = CGRectMake(120, 172, 110, 20);
        }
        
    } //else {
    //NSLog(@"Under iOS 4.0");	// OS 4.0 아래 버전
    //                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     }
    
    
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [self setLabVersion:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [labVersion release];
    [super dealloc];
}

@end
