//
//  Member.h
//  mobileGm
//
//  Created by shim on 12. 11. 10..
//  Copyright (c) 2012년 hanshinit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Member : NSObject {
    NSString *memberKey;
    NSString *memberId;
    NSString *memberName;
    NSString *memberType;
    NSString *memberMobile;
    NSString *memberPost;
    NSString *memberAddr1;
    NSString *memberAddr2;
    NSString *memberDupinfo;
    NSString *memberEmail;

}

@property (copy) NSString *memberKey;
@property (copy) NSString *memberId;
@property (copy) NSString *memberName;
@property (copy) NSString *memberType;
@property (copy) NSString *memberMobile;
@property (copy) NSString *memberPost;
@property (copy) NSString *memberAddr1;
@property (copy) NSString *memberAddr2;
@property (copy) NSString *memberDupinfo;
@property (copy) NSString *memberEmail;

@end
